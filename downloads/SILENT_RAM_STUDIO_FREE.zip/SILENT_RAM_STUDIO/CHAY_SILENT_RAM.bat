@echo off
chcp 65001 >nul
title SILENT RAM & Process Studio (Edition A)
echo ===================================================
echo   SILENT RAM ^& PROCESS STUDIO - EDITION A (FREE)
echo ===================================================
python --version >nul 2>&1
if errorlevel 1 (
    echo [LOI] May chua cai Python 3. Vui long tai Python tai https://www.python.org/downloads/
    pause
    exit /b 1
)
python -c "import psutil" >nul 2>&1
if errorlevel 1 (
    echo [CAI DAT] Dang cai thu vien psutil nhe cho lan chay dau tien...
    pip install -q psutil
)
echo [KHOI CHAY] Dang mo SILENT RAM Studio...
start "" pythonw "%~dp0silent_ram_studio_web.py"
exit /b 0
