import ctypes
import gc
import json
import os
import time
from collections import defaultdict
from typing import Dict, List, Tuple

import psutil

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "process_advisor_db.json")


def load_db() -> dict:
    if os.path.exists(DB_PATH):
        with open(DB_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"red_do_not_close": {}, "yellow_caution": {}, "green_safe_to_close": {}}


ADVISOR_DB = load_db()


def classify_process(name: str, exe_path: str = "") -> Dict[str, str]:
    key = (name or "").strip().lower()
    low_path = (exe_path or "").strip().lower()

    if key in ADVISOR_DB.get("red_do_not_close", {}):
        d = ADVISOR_DB["red_do_not_close"][key]
        return {
            "tier": "RED",
            "tier_label": "KHÔNG NÊN ĐÓNG",
            "title": d["title"],
            "role": d["role"],
            "consequence": d["consequence"],
            "advice": d["advice"],
            "can_kill": False,
        }

    if key in ADVISOR_DB.get("yellow_caution", {}):
        d = ADVISOR_DB["yellow_caution"][key]
        return {
            "tier": "YELLOW",
            "tier_label": "CÂN NHẮC",
            "title": d["title"],
            "role": d["role"],
            "consequence": d["consequence"],
            "advice": d["advice"],
            "can_kill": True,
        }

    if key in ADVISOR_DB.get("green_safe_to_close", {}):
        d = ADVISOR_DB["green_safe_to_close"][key]
        return {
            "tier": "GREEN",
            "tier_label": "AN TOÀN ĐỂ ĐÓNG",
            "title": d["title"],
            "role": d["role"],
            "consequence": d["consequence"],
            "advice": d["advice"],
            "can_kill": True,
        }

    # Suy luận thông minh dựa trên đường dẫn thực thi & hậu tố tên tiến trình
    if low_path.startswith(r"c:\windows\system32") or low_path.startswith(r"c:\windows\syswow64"):
        return {
            "tier": "RED",
            "tier_label": "KHÔNG NÊN ĐÓNG",
            "title": f"{name} (Thành phần hệ thống Windows)",
            "role": "Tiến trình nằm trực tiếp trong thư mục lõi C:\\Windows\\System32.",
            "consequence": "Có nguy cơ gây lỗi tính năng hệ thống hoặc mất ổn định Windows.",
            "advice": "Khóa bảo vệ tự động theo đường dẫn hệ thống. Không nên tắt.",
            "can_kill": False,
        }

    if any(tok in key for tok in ("updater", "update", "crashpad", "telemetry", "overlay", "helper")):
        return {
            "tier": "GREEN",
            "tier_label": "AN TOÀN ĐỂ ĐÓNG",
            "title": f"{name} (Tác vụ phụ trợ)",
            "role": "Tiến trình phụ trợ, kiểm tra cập nhật hoặc gửi báo cáo lỗi chạy nền.",
            "consequence": "Chỉ tạm dừng chức năng phụ trợ, không ảnh hưởng Windows.",
            "advice": "An toàn để đóng khi cần thu hồi RAM nhanh.",
            "can_kill": True,
        }

    return {
        "tier": "YELLOW",
        "tier_label": "CÂN NHẮC",
        "title": name or "Unknown Process",
        "role": "Tiến trình ứng dụng bên thứ ba đang hoạt động trên máy.",
        "consequence": "Có thể làm mất dữ liệu chưa lưu hoặc ngắt tác vụ đang chạy của ứng dụng đó.",
        "advice": "Ưu tiên dùng [Nén RAM mềm] trước; chỉ đóng hẳn khi bạn chắc chắn không đang dùng.",
        "can_kill": True,
    }


def trim_pid_working_set(pid: int) -> bool:
    """Giải phóng bộ nhớ làm việc không dùng (Working Set) qua Win32 API mà không tắt app."""
    PROCESS_SET_QUOTA = 0x0100
    PROCESS_QUERY_INFORMATION = 0x0400
    try:
        handle = ctypes.windll.kernel32.OpenProcess(
            PROCESS_SET_QUOTA | PROCESS_QUERY_INFORMATION, False, int(pid)
        )
        if not handle:
            return False
        try:
            ok = ctypes.windll.psapi.EmptyWorkingSet(handle)
            return bool(ok)
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
    except Exception:
        return False


def get_system_metrics() -> dict:
    vm = psutil.virtual_memory()
    cpu = psutil.cpu_percent(interval=None)
    status = "GOOD" if vm.percent < 70 else ("WARN" if vm.percent < 85 else "CRITICAL")
    return {
        "timestamp": time.strftime("%H:%M:%S"),
        "ram_percent": round(vm.percent, 1),
        "ram_used_gb": round(vm.used / (1024 ** 3), 2),
        "ram_avail_gb": round(vm.available / (1024 ** 3), 2),
        "ram_total_gb": round(vm.total / (1024 ** 3), 2),
        "ram_avail_mb": round(vm.available / (1024 ** 2), 1),
        "cpu_percent": round(cpu, 1),
        "status": status,
    }


def get_grouped_processes(min_ram_mb: float = 8.0) -> List[dict]:
    """Gom nhóm tiến trình cùng tên (vd: nhiều tiến trình con msedge.exe) kèm phân loại 3 tầng."""
    grouped = defaultdict(lambda: {"pids": [], "ram_mb": 0.0, "cpu_pct": 0.0, "exe": "", "name": ""})
    my_pid = os.getpid()

    for p in psutil.process_iter(["pid", "name", "memory_info", "cpu_percent"]):
        try:
            info = p.info
            pname = (info.get("name") or "").strip()
            if not pname:
                continue
            mem = info.get("memory_info")
            ram_mb = (mem.rss / (1024 ** 2)) if mem else 0.0
            if ram_mb < 1.0:
                continue

            key = pname.lower()
            slot = grouped[key]
            slot["name"] = pname
            slot["pids"].append(info["pid"])
            slot["ram_mb"] += ram_mb
            slot["cpu_pct"] += float(info.get("cpu_percent") or 0.0)
            if not slot["exe"]:
                try:
                    slot["exe"] = p.exe() or ""
                except Exception:
                    slot["exe"] = ""
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    results = []
    for key, slot in grouped.items():
        if slot["ram_mb"] < min_ram_mb:
            continue
        adv = classify_process(slot["name"], slot["exe"])
        if my_pid in slot["pids"]:
            adv["tier"] = "RED"
            adv["tier_label"] = "KHÔNG NÊN ĐÓNG"
            adv["can_kill"] = False
            adv["advice"] = "Đây là chính ứng dụng SILENT RAM Studio đang chạy."

        results.append({
            "key": key,
            "name": slot["name"],
            "count": len(slot["pids"]),
            "pids": slot["pids"],
            "ram_mb": round(slot["ram_mb"], 1),
            "cpu_pct": round(min(slot["cpu_pct"], 100.0), 1),
            "exe": slot["exe"],
            **adv,
        })

    results.sort(key=lambda x: x["ram_mb"], reverse=True)
    return results[:80]


def trim_group(pids: List[int]) -> Tuple[int, int]:
    ok_cnt = 0
    for pid in pids:
        if trim_pid_working_set(pid):
            ok_cnt += 1
    return ok_cnt, len(pids)


def terminate_group(name: str, pids: List[int], exe_path: str = "") -> dict:
    adv = classify_process(name, exe_path)
    if adv["tier"] == "RED" or not adv["can_kill"]:
        return {
            "ok": False,
            "closed": 0,
            "message": f"Đã chặn đóng {name}: thuộc nhóm KHÔNG NÊN ĐÓNG ({adv['title']}).",
        }
    closed = 0
    for pid in pids:
        if pid == os.getpid():
            continue
        try:
            psutil.Process(int(pid)).terminate()
            closed += 1
        except Exception:
            pass
    return {
        "ok": closed > 0,
        "closed": closed,
        "message": f"Đã gửi tín hiệu dừng {closed}/{len(pids)} tiến trình {name}.",
    }


def run_smart_boost(close_green: bool = False) -> dict:
    before_vm = psutil.virtual_memory()
    before_avail_mb = before_vm.available / (1024 ** 2)
    before_pct = before_vm.percent

    gc.collect()
    groups = get_grouped_processes(min_ram_mb=15.0)

    trimmed_procs = 0
    closed_green = 0
    for g in groups:
        if g["tier"] == "YELLOW" and g["ram_mb"] >= 40.0:
            ok_c, _ = trim_group(g["pids"])
            trimmed_procs += ok_c
        elif g["tier"] == "GREEN":
            if close_green:
                res = terminate_group(g["name"], g["pids"], g["exe"])
                closed_green += res["closed"]
            else:
                ok_c, _ = trim_group(g["pids"])
                trimmed_procs += ok_c

    # Dọn file tạm an toàn (.tmp, .log, .bak cũ trong TEMP)
    temp_dir = os.environ.get("TEMP", "")
    freed_temp_bytes = 0
    if temp_dir and os.path.isdir(temp_dir):
        for rdir, _, files in os.walk(temp_dir):
            for fn in files:
                if fn.lower().endswith((".tmp", ".bak")):
                    fp = os.path.join(rdir, fn)
                    try:
                        sz = os.path.getsize(fp)
                        os.remove(fp)
                        freed_temp_bytes += sz
                    except OSError:
                        pass

    time.sleep(0.4)
    after_vm = psutil.virtual_memory()
    after_avail_mb = after_vm.available / (1024 ** 2)
    after_pct = after_vm.percent

    reclaimed_mb = round(max(0.0, after_avail_mb - before_avail_mb), 1)
    return {
        "before_pct": round(before_pct, 1),
        "after_pct": round(after_pct, 1),
        "reclaimed_mb": reclaimed_mb,
        "trimmed_procs": trimmed_procs,
        "closed_green": closed_green,
        "temp_freed_mb": round(freed_temp_bytes / (1024 ** 2), 2),
    }
