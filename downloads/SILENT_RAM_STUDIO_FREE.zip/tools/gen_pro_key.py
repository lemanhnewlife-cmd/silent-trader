import hashlib
import hmac
import os
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

APP_FILE = Path(r"D:\ai\san pham\silent_ram_cleaner\pc_app_A_webview\silent_ram_studio_web.py")


def load_secret() -> str:
    env_secret = os.environ.get("SILENT_LICENSE_SECRET", "").strip()
    if env_secret:
        return env_secret
    if APP_FILE.exists():
        text = APP_FILE.read_text(encoding="utf-8", errors="replace")
        m = re.search(r'SILENT_SECRET\s*=\s*os\.environ\.get\(\s*["\']SILENT_LICENSE_SECRET["\']\s*,\s*["\']([^"\']+)["\']', text)
        if m:
            return m.group(1)
    raise RuntimeError("Khong tim thay SILENT_SECRET tu bien moi truong hoac silent_ram_studio_web.py")


def make_pro_token(device_id: str, secret: str) -> str:
    clean_id = (device_id or "").strip().upper()
    if not clean_id:
        raise ValueError("device_id khong duoc rong")
    sig = hmac.new(
        secret.encode("utf-8"),
        f"SILENTPRO:{clean_id}".encode("utf-8"),
        hashlib.sha256,
    ).hexdigest().upper()[:12]
    return f"SPRO-{clean_id}-{sig}"


def main():
    secret = load_secret()
    if len(sys.argv) >= 2:
        device_id = sys.argv[1]
    else:
        device_id = input("Nhap Device ID cua khach (VD: SL-XXXX-YYYY): ").strip()
    token = make_pro_token(device_id, secret)
    print(f"DEVICE_ID : {device_id.strip().upper()}")
    print(f"PRO_TOKEN : {token}")
    print(f"MEMO_MOMO : SILENTPRO {device_id.strip().upper()}")


if __name__ == "__main__":
    main()
