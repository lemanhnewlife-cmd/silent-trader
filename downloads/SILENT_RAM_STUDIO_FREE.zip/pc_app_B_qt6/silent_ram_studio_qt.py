import os
import sys
import time

APP_DIR = os.path.dirname(os.path.abspath(__file__))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from PyQt6.QtCore import Qt, QTimer, QRectF
from PyQt6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen
from PyQt6.QtWidgets import (
    QAbstractItemView, QApplication, QFrame, QHBoxLayout, QHeaderView,
    QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton,
    QStackedWidget, QTableWidget, QTableWidgetItem, QTextEdit,
    QVBoxLayout, QWidget
)

import silent_ram_core as core


class RadialGaugeWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.percent = 0.0
        self.setFixedSize(116, 116)

    def set_value(self, pct: float):
        self.percent = max(0.0, min(100.0, float(pct)))
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(12, 12, self.width() - 24, self.height() - 24)

        bg_pen = QPen(QColor("#1E293B"), 10, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
        p.setPen(bg_pen)
        p.drawArc(rect, 0, 360 * 16)

        color = QColor("#EF4444") if self.percent >= 85 else (QColor("#F59E0B") if self.percent >= 70 else QColor("#10B981"))
        fg_pen = QPen(color, 10, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
        p.setPen(fg_pen)
        span = int(-360 * 16 * (self.percent / 100.0))
        p.drawArc(rect, 90 * 16, span)

        p.setPen(color)
        p.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        p.drawText(QRectF(0, 26, self.width(), 38), Qt.AlignmentFlag.AlignCenter, f"{self.percent:.0f}%")

        p.setPen(QColor("#94A3B8"))
        p.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        p.drawText(QRectF(0, 62, self.width(), 22), Qt.AlignmentFlag.AlignCenter, "RAM")


class SparklineWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.values = []
        self.setMinimumHeight(74)

    def push_value(self, v: float):
        self.values.append(max(0.0, min(100.0, float(v))))
        if len(self.values) > 45:
            self.values = self.values[-45:]
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, QColor("#0E1525"))

        p.setPen(QPen(QColor(148, 163, 184, 30), 1))
        for y in (int(h * 0.25), int(h * 0.5), int(h * 0.75)):
            p.drawLine(0, y, w, y)

        if len(self.values) < 2:
            return

        step = w / max(1, len(self.values) - 1)
        path = QPainterPath()
        pts = []
        for i, val in enumerate(self.values):
            x = i * step
            y = h - (val / 100.0) * (h - 12) - 6
            pts.append((x, y))
            if i == 0:
                path.moveTo(x, y)
            else:
                path.lineTo(x, y)

        latest = self.values[-1]
        col = QColor("#EF4444") if latest >= 85 else (QColor("#F59E0B") if latest >= 70 else QColor("#10B981"))

        fill_path = QPainterPath(path)
        fill_path.lineTo(pts[-1][0], h)
        fill_path.lineTo(0, h)
        fill_path.closeSubpath()

        grad = QLinearGradient(0, 0, 0, h)
        c_top = QColor(col)
        c_top.setAlpha(75)
        c_bot = QColor(col)
        c_bot.setAlpha(0)
        grad.setColorAt(0, c_top)
        grad.setColorAt(1, c_bot)
        p.fillPath(fill_path, grad)

        p.setPen(QPen(col, 2.4))
        p.drawPath(path)


class SilentRamStudioQt(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SILENT RAM & Process Studio — Edition B (Qt6 Native)")
        self.resize(1240, 740)
        self.setMinimumSize(980, 620)

        self.all_procs = []
        self.filtered_procs = []
        self.selected_proc = None
        self.current_tier = "ALL"
        self.session_reclaimed = 0.0

        self._apply_qss()
        self._build_ui()
        self.refresh_all()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_all)
        self.timer.start(2500)

    def _apply_qss(self):
        self.setStyleSheet("""
            QMainWindow, QWidget { background-color: #070B14; color: #F3F4F6; font-family: 'Segoe UI'; }
            QFrame#Sidebar { background-color: #0B1120; border-right: 1px solid #23304A; }
            QFrame#AdvisorPanel { background-color: #0B1120; border-left: 1px solid #23304A; }
            QFrame#Card { background-color: #111827; border: 1px solid #23304A; border-radius: 12px; }
            QFrame#SubCard { background-color: #161F33; border: 1px solid #23304A; border-radius: 10px; }
            QPushButton#NavBtn {
                text-align: left; padding: 11px 14px; border-radius: 9px;
                background: transparent; color: #94A3B8; font-size: 13px; font-weight: 600; border: none;
            }
            QPushButton#NavBtn:hover { background: #161F33; color: #FFFFFF; }
            QPushButton#NavBtn[active="true"] { background: #1E3A8A; color: #FFFFFF; }
            QPushButton#PrimaryBtn {
                background: #2563EB; color: #FFFFFF; border-radius: 9px;
                padding: 9px 14px; font-weight: 700; border: none;
            }
            QPushButton#PrimaryBtn:hover { background: #1D4ED8; }
            QPushButton#BoostBtn {
                background: #10B981; color: #022C22; border-radius: 9px;
                padding: 9px 14px; font-weight: 800; border: none;
            }
            QPushButton#BoostBtn:hover { background: #059669; color: #FFFFFF; }
            QPushButton#DangerBtn {
                background: #DC2626; color: #FFFFFF; border-radius: 9px;
                padding: 10px 14px; font-weight: 700; border: none;
            }
            QPushButton#DangerBtn:disabled { background: #334155; color: #94A3B8; }
            QPushButton#PillBtn {
                background: #111827; color: #94A3B8; border: 1px solid #23304A;
                border-radius: 14px; padding: 6px 12px; font-weight: 700; font-size: 12px;
            }
            QPushButton#PillBtn[active="true"] { background: #2563EB; color: #FFFFFF; border-color: #3B82F6; }
            QLineEdit {
                background: #111827; color: #F8FAFC; border: 1px solid #23304A;
                border-radius: 9px; padding: 8px 12px; font-size: 13px;
            }
            QLineEdit:focus { border-color: #3B82F6; }
            QTableWidget {
                background: #111827; border: 1px solid #23304A; border-radius: 12px;
                gridline-color: #1E293B; selection-background-color: #1D4ED8;
            }
            QHeaderView::section {
                background: #0D1424; color: #94A3B8; padding: 9px 12px;
                border: none; border-bottom: 1px solid #23304A; font-weight: 700; font-size: 11px;
            }
            QTextEdit {
                background: #111827; color: #CBD5E1; border: 1px solid #23304A;
                border-radius: 12px; padding: 10px; font-family: Consolas; font-size: 12px;
            }
        """)

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root_lay = QHBoxLayout(central)
        root_lay.setContentsMargins(0, 0, 0, 0)
        root_lay.setSpacing(0)

        # 1. Sidebar
        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(225)
        sb_lay = QVBoxLayout(sidebar)
        sb_lay.setContentsMargins(14, 18, 14, 16)
        sb_lay.setSpacing(8)

        lbl_brand = QLabel("SILENT STUDIO")
        lbl_brand.setStyleSheet("font-size:17px; font-weight:900; color:#FFFFFF; background:transparent;")
        lbl_sub = QLabel("Qt6 Native • RAM Advisor")
        lbl_sub.setStyleSheet("font-size:11px; color:#64748B; background:transparent; margin-bottom:12px;")
        sb_lay.addWidget(lbl_brand)
        sb_lay.addWidget(lbl_sub)

        self.nav_btns = []
        for idx, text in enumerate(["Tổng quan & Tiến trình", "Dọn dẹp 1 chạm (Boost)", "Nhật ký an toàn"]):
            b = QPushButton(text)
            b.setObjectName("NavBtn")
            b.setProperty("active", "true" if idx == 0 else "false")
            b.clicked.connect(lambda _=False, i=idx: self._switch_tab(i))
            sb_lay.addWidget(b)
            self.nav_btns.append(b)

        sb_lay.addStretch()

        status_card = QFrame()
        status_card.setObjectName("SubCard")
        sc_lay = QVBoxLayout(status_card)
        self.lbl_sys_state = QLabel("Đang quét hệ thống...")
        self.lbl_sys_state.setStyleSheet("font-weight:700; font-size:12px; background:transparent;")
        self.lbl_db_info = QLabel("Advisor DB: 128 tiến trình")
        self.lbl_db_info.setStyleSheet("font-size:11px; color:#94A3B8; background:transparent;")
        sc_lay.addWidget(self.lbl_sys_state)
        sc_lay.addWidget(self.lbl_db_info)
        sb_lay.addWidget(status_card)

        root_lay.addWidget(sidebar)

        # 2. Center Workspace
        center = QWidget()
        c_lay = QVBoxLayout(center)
        c_lay.setContentsMargins(18, 16, 18, 16)
        c_lay.setSpacing(12)

        # Header
        head_row = QHBoxLayout()
        h_left = QVBoxLayout()
        t_lbl = QLabel("SILENT RAM & Process Studio")
        t_lbl.setStyleSheet("font-size:19px; font-weight:800;")
        s_lbl = QLabel("Giám sát RAM thực tế & Tư vấn tiến trình 3 cấp Đỏ / Vàng / Xanh")
        s_lbl.setStyleSheet("font-size:12px; color:#94A3B8;")
        h_left.addWidget(t_lbl)
        h_left.addWidget(s_lbl)
        head_row.addLayout(h_left)
        head_row.addStretch()

        btn_ref = QPushButton("Làm mới")
        btn_ref.setObjectName("PrimaryBtn")
        btn_ref.clicked.connect(self.refresh_all)
        btn_boost = QPushButton("Smart Boost (Nén RAM mềm)")
        btn_boost.setObjectName("BoostBtn")
        btn_boost.clicked.connect(lambda: self.run_boost(False))
        head_row.addWidget(btn_ref)
        head_row.addWidget(btn_boost)
        c_lay.addLayout(head_row)

        # Telemetry Row
        tel_row = QHBoxLayout()
        tel_row.setSpacing(12)

        gauge_card = QFrame()
        gauge_card.setObjectName("Card")
        gc_lay = QHBoxLayout(gauge_card)
        self.gauge = RadialGaugeWidget()
        gc_lay.addWidget(self.gauge)

        meta_lay = QVBoxLayout()
        self.lbl_used = QLabel("Đang dùng: -- GB")
        self.lbl_used.setStyleSheet("font-size:13px; font-weight:700; background:transparent;")
        self.lbl_avail = QLabel("Khả dụng: -- GB")
        self.lbl_avail.setStyleSheet("font-size:13px; font-weight:700; color:#10B981; background:transparent;")
        self.lbl_cpu = QLabel("CPU: --%")
        self.lbl_cpu.setStyleSheet("font-size:12px; color:#94A3B8; background:transparent;")
        meta_lay.addWidget(self.lbl_used)
        meta_lay.addWidget(self.lbl_avail)
        meta_lay.addWidget(self.lbl_cpu)
        gc_lay.addLayout(meta_lay)
        tel_row.addWidget(gauge_card, 4)

        spark_card = QFrame()
        spark_card.setObjectName("Card")
        sp_lay = QVBoxLayout(spark_card)
        sp_top = QHBoxLayout()
        lbl_sp = QLabel("Biểu đồ RAM thời gian thực")
        lbl_sp.setStyleSheet("font-size:12px; font-weight:700; color:#CBD5E1; background:transparent;")
        self.lbl_reclaimed = QLabel("Đã thu hồi: 0.0 MB")
        self.lbl_reclaimed.setStyleSheet("font-size:12px; font-weight:700; color:#10B981; background:transparent;")
        sp_top.addWidget(lbl_sp)
        sp_top.addStretch()
        sp_top.addWidget(self.lbl_reclaimed)
        sp_lay.addLayout(sp_top)
        self.sparkline = SparklineWidget()
        sp_lay.addWidget(self.sparkline)
        tel_row.addWidget(spark_card, 6)

        c_lay.addLayout(tel_row)

        # Stacked Views
        self.stack = QStackedWidget()
        c_lay.addWidget(self.stack, 1)

        # Tab 0: Process Table
        tab0 = QWidget()
        t0_lay = QVBoxLayout(tab0)
        t0_lay.setContentsMargins(0, 0, 0, 0)
        t0_lay.setSpacing(10)

        f_row = QHBoxLayout()
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Tìm tiến trình (msedge, msmpeng, svchost, antigravity)...")
        self.search_edit.textChanged.connect(self._render_table)
        f_row.addWidget(self.search_edit, 1)

        self.pill_btns = {}
        for code, lbl in [("ALL", "Tất cả"), ("GREEN", "Xanh"), ("YELLOW", "Vàng"), ("RED", "Đỏ - Cấm đóng")]:
            pb = QPushButton(lbl)
            pb.setObjectName("PillBtn")
            pb.setProperty("active", "true" if code == "ALL" else "false")
            pb.clicked.connect(lambda _=False, c=code: self._set_tier(c))
            f_row.addWidget(pb)
            self.pill_btns[code] = pb
        t0_lay.addLayout(f_row)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["TIẾN TRÌNH (GOM NHÓM)", "TÊN HIỂN THỊ", "MỨC ĐỘ AN TOÀN", "RAM (MB)"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.itemSelectionChanged.connect(self._on_row_selected)
        t0_lay.addWidget(self.table, 1)
        self.stack.addWidget(tab0)

        # Tab 1: Boost
        tab1 = QWidget()
        t1_lay = QVBoxLayout(tab1)
        boost_card = QFrame()
        boost_card.setObjectName("Card")
        bc_lay = QVBoxLayout(boost_card)
        lbl_bt = QLabel("Trung tâm Dọn dẹp 1 chạm SILENT")
        lbl_bt.setStyleSheet("font-size:15px; font-weight:800; background:transparent;")
        lbl_bd = QLabel("Nén bộ nhớ làm việc (EmptyWorkingSet) cho ứng dụng nhóm Vàng và dọn file tạm an toàn mà không tắt phần mềm đang chạy.")
        lbl_bd.setWordWrap(True)
        lbl_bd.setStyleSheet("color:#94A3B8; font-size:13px; background:transparent; margin-bottom:10px;")
        b_row = QHBoxLayout()
        b_soft = QPushButton("Chạy Smart Boost (Giữ app mở)")
        b_soft.setObjectName("BoostBtn")
        b_soft.clicked.connect(lambda: self.run_boost(False))
        b_deep = QPushButton("Chạy Dọn Sâu (Đóng thêm nhóm Xanh)")
        b_deep.setObjectName("PrimaryBtn")
        b_deep.clicked.connect(lambda: self.run_boost(True))
        b_row.addWidget(b_soft)
        b_row.addWidget(b_deep)
        self.lbl_boost_res = QLabel("Chưa chạy lượt dọn nào trong phiên này.")
        self.lbl_boost_res.setStyleSheet("color:#6EE7B7; font-weight:700; margin-top:10px; background:transparent;")
        bc_lay.addWidget(lbl_bt)
        bc_lay.addWidget(lbl_bd)
        bc_lay.addLayout(b_row)
        bc_lay.addWidget(self.lbl_boost_res)
        t1_lay.addWidget(boost_card)
        t1_lay.addStretch()
        self.stack.addWidget(tab1)

        # Tab 2: Logs
        tab2 = QWidget()
        t2_lay = QVBoxLayout(tab2)
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.append("[SILENT] Đã kích hoạt Smart Process Advisor 3 tầng (Đỏ / Vàng / Xanh).")
        t2_lay.addWidget(self.log_box)
        self.stack.addWidget(tab2)

        root_lay.addWidget(center, 1)

        # 3. Right Panel: Process Advisor
        adv_panel = QFrame()
        adv_panel.setObjectName("AdvisorPanel")
        adv_panel.setFixedWidth(335)
        ap_lay = QVBoxLayout(adv_panel)
        ap_lay.setContentsMargins(16, 18, 16, 16)
        ap_lay.setSpacing(10)

        lbl_ah = QLabel("SMART PROCESS ADVISOR")
        lbl_ah.setStyleSheet("color:#06B6D4; font-size:12px; font-weight:800; letter-spacing:1px; background:transparent;")
        ap_lay.addWidget(lbl_ah)

        adv_card = QFrame()
        adv_card.setObjectName("SubCard")
        ac_lay = QVBoxLayout(adv_card)
        ac_lay.setSpacing(9)

        self.lbl_adv_badge = QLabel("CHỌN 1 TIẾN TRÌNH")
        self.lbl_adv_badge.setStyleSheet("background:#334155; color:#FFFFFF; padding:5px 10px; border-radius:8px; font-weight:800; font-size:11px;")
        ac_lay.addWidget(self.lbl_adv_badge)

        self.lbl_adv_title = QLabel("Nhấp vào 1 dòng trong bảng")
        self.lbl_adv_title.setWordWrap(True)
        self.lbl_adv_title.setStyleSheet("font-size:16px; font-weight:800; background:transparent;")
        ac_lay.addWidget(self.lbl_adv_title)

        self.lbl_adv_meta = QLabel("--")
        self.lbl_adv_meta.setWordWrap(True)
        self.lbl_adv_meta.setStyleSheet("font-size:12px; color:#94A3B8; background:transparent;")
        ac_lay.addWidget(self.lbl_adv_meta)

        self.lbl_adv_role = QLabel("Vai trò: --")
        self.lbl_adv_role.setWordWrap(True)
        self.lbl_adv_role.setStyleSheet("background:#0B1120; padding:9px; border-radius:8px; font-size:12px; color:#E2E8F0;")
        ac_lay.addWidget(self.lbl_adv_role)

        self.lbl_adv_cons = QLabel("Nếu đóng: --")
        self.lbl_adv_cons.setWordWrap(True)
        self.lbl_adv_cons.setStyleSheet("background:#0B1120; border-left:3px solid #EF4444; padding:9px; border-radius:8px; font-size:12px; color:#FCA5A5;")
        ac_lay.addWidget(self.lbl_adv_cons)

        self.lbl_adv_tip = QLabel("SILENT khuyên: --")
        self.lbl_adv_tip.setWordWrap(True)
        self.lbl_adv_tip.setStyleSheet("background:#0B1120; border-left:3px solid #10B981; padding:9px; border-radius:8px; font-size:12px; color:#6EE7B7; font-weight:600;")
        ac_lay.addWidget(self.lbl_adv_tip)

        self.btn_trim = QPushButton("Nén RAM mềm (Trim Working Set)")
        self.btn_trim.setObjectName("PrimaryBtn")
        self.btn_trim.clicked.connect(self.trim_selected)
        ac_lay.addWidget(self.btn_trim)

        self.btn_kill = QPushButton("Đóng tiến trình đã chọn")
        self.btn_kill.setObjectName("DangerBtn")
        self.btn_kill.clicked.connect(self.kill_selected)
        ac_lay.addWidget(self.btn_kill)

        ap_lay.addWidget(adv_card)
        ap_lay.addStretch()
        root_lay.addWidget(adv_panel)

    def _switch_tab(self, idx: int):
        self.stack.setCurrentIndex(idx)
        for i, b in enumerate(self.nav_btns):
            b.setProperty("active", "true" if i == idx else "false")
            b.style().unpolish(b)
            b.style().polish(b)

    def _set_tier(self, code: str):
        self.current_tier = code
        for c, b in self.pill_btns.items():
            b.setProperty("active", "true" if c == code else "false")
            b.style().unpolish(b)
            b.style().polish(b)
        self._render_table()

    def _log(self, msg: str):
        self.log_box.append(f"[{time.strftime('%H:%M:%S')}] {msg}")

    def refresh_all(self):
        m = core.get_system_metrics()
        self.gauge.set_value(m["ram_percent"])
        self.sparkline.push_value(m["ram_percent"])
        self.lbl_used.setText(f"Đang dùng: {m['ram_used_gb']} / {m['ram_total_gb']} GB")
        self.lbl_avail.setText(f"Khả dụng: {m['ram_avail_gb']} GB")
        self.lbl_cpu.setText(f"CPU hiện tại: {m['cpu_percent']}%")

        st_txt = "RAM CĂNG — Nên dọn" if m["ram_percent"] >= 85 else ("Tải trung bình" if m["ram_percent"] >= 70 else "Hệ thống ổn định")
        st_col = "#EF4444" if m["ram_percent"] >= 85 else ("#F59E0B" if m["ram_percent"] >= 70 else "#10B981")
        self.lbl_sys_state.setText(st_txt)
        self.lbl_sys_state.setStyleSheet(f"font-weight:700; font-size:12px; color:{st_col}; background:transparent;")

        prev_key = self.selected_proc["key"] if self.selected_proc else None
        self.all_procs = core.get_grouped_processes(min_ram_mb=8.0)
        self._render_table(prev_key)

    def _render_table(self, keep_key=None):
        q = self.search_edit.text().strip().lower()
        self.filtered_procs = [
            p for p in self.all_procs
            if (self.current_tier == "ALL" or p["tier"] == self.current_tier)
            and (not q or q in p["name"].lower() or q in p["title"].lower())
        ]
        self.table.setRowCount(len(self.filtered_procs))
        row_to_select = -1
        for i, p in enumerate(self.filtered_procs):
            it_name = QTableWidgetItem(f"{p['name']}  (x{p['count']})")
            it_title = QTableWidgetItem(p["title"])
            it_tier = QTableWidgetItem(p["tier_label"])
            it_ram = QTableWidgetItem(f"{p['ram_mb']:.1f} MB")
            it_ram.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)

            t_col = QColor("#FCA5A5") if p["tier"] == "RED" else (QColor("#FCD34D") if p["tier"] == "YELLOW" else QColor("#6EE7B7"))
            it_tier.setForeground(t_col)

            self.table.setItem(i, 0, it_name)
            self.table.setItem(i, 1, it_title)
            self.table.setItem(i, 2, it_tier)
            self.table.setItem(i, 3, it_ram)
            if keep_key and p["key"] == keep_key:
                row_to_select = i

        if row_to_select >= 0:
            self.table.selectRow(row_to_select)
        elif not self.selected_proc and self.filtered_procs:
            self.table.selectRow(0)

    def _on_row_selected(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.filtered_procs):
            return
        p = self.filtered_procs[row]
        self.selected_proc = p

        bg = "#991B1B" if p["tier"] == "RED" else ("#92400E" if p["tier"] == "YELLOW" else "#065F46")
        self.lbl_adv_badge.setText(p["tier_label"])
        self.lbl_adv_badge.setStyleSheet(f"background:{bg}; color:#FFFFFF; padding:5px 10px; border-radius:8px; font-weight:800; font-size:11px;")
        self.lbl_adv_title.setText(p["title"])
        self.lbl_adv_meta.setText(f"{p['name']} ({p['count']} tiến trình) • {p['ram_mb']:.1f} MB RAM")
        self.lbl_adv_role.setText(f"Vai trò: {p['role']}")
        self.lbl_adv_cons.setText(f"Nếu đóng: {p['consequence']}")
        self.lbl_adv_tip.setText(f"SILENT khuyên: {p['advice']}")

        if p["tier"] == "RED" or not p["can_kill"]:
            self.btn_kill.setEnabled(False)
            self.btn_kill.setText("Đã khóa bảo vệ (Lõi Windows)")
        else:
            self.btn_kill.setEnabled(True)
            self.btn_kill.setText(f"Đóng {p['name']} (x{p['count']})")

    def trim_selected(self):
        if not self.selected_proc:
            return
        ok_c, tot_c = core.trim_group(self.selected_proc["pids"])
        msg = f"Đã nén RAM mềm {ok_c}/{tot_c} tiến trình {self.selected_proc['name']}."
        self._log(msg)
        QMessageBox.information(self, "SILENT Smart Trim", msg)
        self.refresh_all()

    def kill_selected(self):
        p = self.selected_proc
        if not p or not p["can_kill"]:
            return
        if p["tier"] == "YELLOW":
            ans = QMessageBox.question(
                self, "Cảnh báo tiến trình Vàng",
                f"{p['name']} thuộc nhóm CÂN NHẮC.\nHậu quả: {p['consequence']}\n\nBạn vẫn muốn đóng?"
            )
            if ans != QMessageBox.StandardButton.Yes:
                return
        res = core.terminate_group(p["name"], p["pids"], p["exe"])
        self._log(res["message"])
        QMessageBox.information(self, "SILENT Advisor", res["message"])
        self.refresh_all()

    def run_boost(self, close_green: bool):
        r = core.run_smart_boost(close_green=close_green)
        self.session_reclaimed += r["reclaimed_mb"]
        self.lbl_reclaimed.setText(f"Đã thu hồi: +{self.session_reclaimed:.1f} MB")
        msg = f"RAM {r['before_pct']}% -> {r['after_pct']}% (+{r['reclaimed_mb']} MB, nén {r['trimmed_procs']} tiến trình, dọn {r['temp_freed_mb']} MB file tạm)."
        self.lbl_boost_res.setText(msg)
        self._log("Smart Boost: " + msg)
        QMessageBox.information(self, "SILENT Smart Boost", msg)
        self.refresh_all()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = SilentRamStudioQt()
    win.show()
    sys.exit(app.exec())
