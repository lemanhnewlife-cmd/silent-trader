/**
 * SILENT RAM STUDIO — MoMo Auto-Unlock Webhook Worker (Cloudflare Workers + KV)
 * 1. Tạo KV Namespace tên: SILENT_LICENSES
 * 2. Thêm Secret: SILENT_SECRET (trùng khớp với SILENT_SECRET trong silent_ram_studio_web.py)
 * 3. Trỏ Webhook biến động số dư (SePay / Casso / AutoMoMo) về: POST https://<worker>/webhook/momo
 * 4. Trang silent-ram-cleaner.html gọi GET https://<worker>/check?device_id=SL-XXXX-YYYY mỗi 3 giây
 */
async function signToken(secret, deviceId) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sigBuf = await crypto.subtle.sign("HMAC", key, enc.encode("SILENTPRO:" + deviceId.toUpperCase()));
  const hex = [...new Uint8Array(sigBuf)].map(b => b.toString(16).padStart(2, "0")).join("").slice(0, 12).toUpperCase();
  return `SPRO-${deviceId.toUpperCase()}-${hex}`;
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const cors = { "Access-Control-Allow-Origin": "*", "Content-Type": "application/json" };

    if (req.method === "POST" && url.pathname === "/webhook/momo") {
      const body = await req.json();
      const content = String(body.content || body.description || body.comment || "").toUpperCase();
      const amount = Number(body.transferAmount || body.amount || 0);
      const match = content.match(/SL-[A-F0-9]{4}-[A-F0-9]{4}/);
      if (match && amount >= 49000) {
        const deviceId = match[0];
        const token = await signToken(env.SILENT_SECRET, deviceId);
        await env.SILENT_LICENSES.put(deviceId, JSON.stringify({ paid: true, token, tx_ref: body.referenceCode || "MOMO-OK" }));
      }
      return new Response(JSON.stringify({ ok: true }), { headers: cors });
    }

    if (req.method === "GET" && url.pathname === "/check") {
      const deviceId = (url.searchParams.get("device_id") || "").toUpperCase();
      const raw = deviceId ? await env.SILENT_LICENSES.get(deviceId) : null;
      return new Response(raw || JSON.stringify({ paid: false }), { headers: cors });
    }

    return new Response(JSON.stringify({ status: "SILENT_MOMO_WORKER_READY" }), { headers: cors });
  }
};
