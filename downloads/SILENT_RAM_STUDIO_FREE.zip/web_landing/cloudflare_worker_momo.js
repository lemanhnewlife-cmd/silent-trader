/**
 * SILENT RAM STUDIO - MoMo Auto-Unlock Webhook Worker (Cloudflare Workers + KV)
 * Secrets required:
 *   - SILENT_SECRET: HMAC key matching silent_ram_studio_web.py
 *   - WEBHOOK_SECRET: Auth token for SePay / Casso / AutoMoMo webhook calls
 */
async function signToken(secret, deviceId) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sigBuf = await crypto.subtle.sign(
    "HMAC",
    key,
    enc.encode("SILENTPRO:" + deviceId.toUpperCase())
  );
  const hex = [...new Uint8Array(sigBuf)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
    .slice(0, 12)
    .toUpperCase();
  return `SPRO-${deviceId.toUpperCase()}-${hex}`;
}

function extractWebhookToken(req, url) {
  const auth = (req.headers.get("Authorization") || "").trim();
  if (auth) {
    const m = auth.match(/^(?:Apikey|Bearer)\s+(.+)$/i);
    if (m) return m[1].trim();
  }
  const direct =
    req.headers.get("secure-token") ||
    req.headers.get("x-webhook-secret") ||
    url.searchParams.get("secret") ||
    "";
  return direct.trim();
}

function safeEqual(a, b) {
  if (!a || !b || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Webhook-Secret, secure-token",
      "Content-Type": "application/json",
    };

    if (req.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: cors });
    }

    if (req.method === "POST" && url.pathname === "/webhook/momo") {
      const expectedSecret = (env.WEBHOOK_SECRET || "").trim();
      if (!expectedSecret) {
        return new Response(JSON.stringify({ ok: false, error: "WEBHOOK_SECRET_NOT_CONFIGURED" }), {
          status: 503,
          headers: cors,
        });
      }
      const provided = extractWebhookToken(req, url);
      if (!safeEqual(provided, expectedSecret)) {
        return new Response(JSON.stringify({ ok: false, error: "UNAUTHORIZED" }), {
          status: 401,
          headers: cors,
        });
      }

      let body;
      try {
        body = await req.json();
      } catch {
        return new Response(JSON.stringify({ ok: false, error: "INVALID_JSON" }), {
          status: 400,
          headers: cors,
        });
      }

      const content = String(body.content || body.description || body.comment || "").toUpperCase();
      const amount = Number(body.transferAmount || body.amount || 0);
      const match = content.match(/SL-[A-F0-9]{4}-[A-F0-9]{4}/);
      if (match && amount >= 49000) {
        const deviceId = match[0];
        const token = await signToken(env.SILENT_SECRET, deviceId);
        await env.SILENT_LICENSES.put(
          deviceId,
          JSON.stringify({
            paid: true,
            token,
            tx_ref: body.referenceCode || body.id || "MOMO-OK",
            amount,
            paid_at: new Date().toISOString(),
          })
        );
        return new Response(JSON.stringify({ ok: true, unlocked: true, device_id: deviceId }), {
          headers: cors,
        });
      }
      return new Response(JSON.stringify({ ok: true, unlocked: false }), { headers: cors });
    }

    if (req.method === "GET" && url.pathname === "/check") {
      const deviceId = (url.searchParams.get("device_id") || "").toUpperCase();
      const raw = deviceId ? await env.SILENT_LICENSES.get(deviceId) : null;
      return new Response(raw || JSON.stringify({ paid: false }), { headers: cors });
    }

    return new Response(JSON.stringify({ status: "SILENT_MOMO_WORKER_READY", auth: true }), {
      headers: cors,
    });
  },
};
