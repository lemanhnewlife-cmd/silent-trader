import hashlib
import hmac
import json
import os
import platform
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

APP_DIR = os.path.dirname(os.path.abspath(__file__))
UI_DIR = os.path.join(APP_DIR, "ui")
WEB_LANDING_DIR = os.path.abspath(os.path.join(APP_DIR, "..", "web_landing"))
LICENSE_FILE = os.path.join(APP_DIR, "silent_license.json")

if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

import silent_ram_core as core

# Đổi chuỗi này khớp với Cloudflare Worker trước khi đóng gói bản thương mại (.exe)
SILENT_SECRET = os.environ.get("SILENT_LICENSE_SECRET", "SILENT_PRO_SECRET_2026_PROD_98166")
# Khi đẩy lên GitHub Pages, đặt biến môi trường hoặc thay trực tiếp URL bên dưới:
# Ví dụ: "https://lemanhnewlife-cmd.github.io/silent-trader/silent-ram-cleaner.html"
PUBLIC_CHECKOUT_URL = os.environ.get("SILENT_CHECKOUT_URL", "https://lemanhnewlife-cmd.github.io/silent-trader/silent-ram-cleaner.html")
# Endpoint Cloudflare Worker kiểm tra giao dịch MoMo (tuỳ chọn, cho trường hợp quét bằng điện thoại)
VERIFY_API_URL = os.environ.get("SILENT_VERIFY_API", "https://silent-momo-worker.silent-trader.workers.dev")

ACTIVE_PORT = 18765


def get_device_id() -> str:
    raw = f"{platform.node()}|{os.getlogin()}|{platform.machine()}|SILENT_RAM_A"
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest().upper()
    return f"SL-{digest[:4]}-{digest[4:8]}"


def make_pro_token(device_id: str) -> str:
    sig = hmac.new(
        SILENT_SECRET.encode("utf-8"),
        f"SILENTPRO:{device_id.upper()}".encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()[:12].upper()
    return f"SPRO-{device_id.upper()}-{sig}"


def verify_pro_token(device_id: str, token: str) -> bool:
    expected = make_pro_token(device_id)
    return hmac.compare_digest((token or "").strip().upper(), expected)


def read_license() -> dict:
    dev_id = get_device_id()
    if os.path.exists(LICENSE_FILE):
        try:
            with open(LICENSE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("device_id") == dev_id and verify_pro_token(dev_id, data.get("token", "")):
                return {
                    "unlocked": True,
                    "plan": "PRO",
                    "device_id": dev_id,
                    "unlocked_at": data.get("unlocked_at", ""),
                    "tx_ref": data.get("tx_ref", ""),
                }
        except Exception:
            pass
    return {
        "unlocked": False,
        "plan": "FREE",
        "device_id": dev_id,
        "unlocked_at": "",
        "tx_ref": "",
    }


def save_license(device_id: str, token: str, tx_ref: str = "") -> bool:
    if not verify_pro_token(device_id, token):
        return False
    payload = {
        "device_id": device_id.upper(),
        "token": token.strip().upper(),
        "tx_ref": tx_ref,
        "unlocked_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    with open(LICENSE_FILE, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    return True


def build_checkout_url(port: int) -> str:
    dev_id = get_device_id()
    cb = f"http://127.0.0.1:{port}/api/license/callback"
    base = PUBLIC_CHECKOUT_URL.strip() or f"http://127.0.0.1:{port}/checkout/silent-ram-cleaner.html"
    qs = urllib.parse.urlencode({"device_id": dev_id, "callback": cb, "source": "app_a"})
    sep = "&" if "?" in base else "?"
    return f"{base}{sep}{qs}"


def find_free_port(start: int = 18765) -> int:
    for port in range(start, start + 50):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    return 0


class SilentAPIHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=UI_DIR, **kwargs)

    def log_message(self, format, *args):
        pass

    def _send_json(self, obj, status: int = 200):
        raw = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(raw)

    def _send_html(self, html: str, status: int = 200):
        raw = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        params = urllib.parse.parse_qs(parsed.query)

        # 1. API trạng thái hệ thống + bản quyền
        if path == "/api/snapshot":
            lic = read_license()
            lic["checkout_url"] = build_checkout_url(ACTIVE_PORT)
            lic["verify_api"] = VERIFY_API_URL
            self._send_json({
                "license": lic,
                "metrics": core.get_system_metrics(),
                "processes": core.get_grouped_processes(min_ram_mb=8.0),
            })
            return

        if path == "/api/license/status":
            lic = read_license()
            lic["checkout_url"] = build_checkout_url(ACTIVE_PORT)
            self._send_json(lic)
            return

        # 2. Callback tự động mở khóa khi trang web MoMo chuyển hướng về sau thanh toán
        if path == "/api/license/callback":
            dev_id = (params.get("device_id", [get_device_id()])[0]).strip().upper()
            token = (params.get("token", [""])[0]).strip().upper()
            tx_ref = (params.get("tx_ref", ["MOMO-AUTO"])[0]).strip()
            if dev_id == get_device_id() and save_license(dev_id, token, tx_ref):
                self._send_html(f"""<!DOCTYPE html>
<html lang="vi"><head><meta charset="UTF-8"><title>SILENT PRO Đã Mở Khóa</title>
<style>body{{margin:0;background:#070b14;color:#f3f4f6;font-family:'Segoe UI',sans-serif;display:grid;place-items:center;height:100vh;}}
.box{{background:#111827;border:2px solid #10b981;border-radius:16px;padding:28px 34px;text-align:center;max-width:460px;}}
h2{{color:#10b981;margin:0 0 10px;}}p{{color:#cbd5e1;font-size:14px;line-height:1.5;}}</style></head>
<body><div class="box"><h2>ĐÃ MỞ KHÓA SILENT PRO!</h2>
<p>Mã thiết bị: <strong>{dev_id}</strong><br/>Mã giao dịch: <strong>{tx_ref}</strong></p>
<p>Toàn bộ tính năng dọn RAM (Smart Boost, Nén RAM mềm, Đóng tiến trình) đã tự động mở trong ứng dụng <strong>SILENT RAM Studio</strong>. Bạn có thể đóng tab này và quay lại ứng dụng.</p>
</div></body></html>""")
                return
            self._send_html("<h3>Mã kích hoạt không hợp lệ hoặc không khớp thiết bị.</h3>", 400)
            return

        # 3. Endpoint giả lập tạo token hợp lệ CHỈ PHỤC VỤ TEST TRÊN LOCALHOST (127.0.0.1)
        if path == "/api/dev/simulate_momo_paid":
            dev_id = (params.get("device_id", [get_device_id()])[0]).strip().upper()
            if dev_id != get_device_id():
                self._send_json({"ok": False, "message": "Sai device_id"}, 400)
                return
            token = make_pro_token(dev_id)
            self._send_json({"ok": True, "device_id": dev_id, "token": token, "tx_ref": f"MOMO-TEST-{int(time.time())%10000}"})
            return

        # 4. Phục vụ trang Web Checkout MoMo cục bộ tại /checkout/*
        if path.startswith("/checkout/"):
            rel = path[len("/checkout/"):].lstrip("/") or "silent-ram-cleaner.html"
            safe_path = os.path.abspath(os.path.join(WEB_LANDING_DIR, rel))
            if safe_path.startswith(WEB_LANDING_DIR) and os.path.isfile(safe_path):
                ext = os.path.splitext(safe_path)[1].lower()
                ctype = {
                    ".html": "text/html; charset=utf-8",
                    ".png": "image/png",
                    ".jpg": "image/jpeg",
                    ".css": "text/css",
                    ".js": "application/javascript",
                }.get(ext, "application/octet-stream")
                with open(safe_path, "rb") as f:
                    data = f.read()
                self.send_response(200)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return

        super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length).decode("utf-8") if length > 0 else "{}"
        data = json.loads(body or "{}")

        if path == "/api/license/open_checkout":
            url = build_checkout_url(ACTIVE_PORT)
            webbrowser.open(url)
            self._send_json({"ok": True, "checkout_url": url})
            return

        if path == "/api/license/activate":
            dev_id = get_device_id()
            token = (data.get("token") or "").strip().upper()
            tx_ref = (data.get("tx_ref") or "MANUAL-KEY").strip()
            if save_license(dev_id, token, tx_ref):
                self._send_json({"ok": True, "message": "Kích hoạt SILENT PRO thành công! Đã mở toàn bộ tính năng dọn RAM."})
            else:
                self._send_json({"ok": False, "message": "Mã kích hoạt chưa đúng với thiết bị này. Vui lòng kiểm tra lại."}, 400)
            return

        if path == "/api/license/reset_free":
            if os.path.exists(LICENSE_FILE):
                os.remove(LICENSE_FILE)
            self._send_json({"ok": True, "message": "Đã chuyển về chế độ FREE để test lại luồng khóa."})
            return

        # CỔNG PAYWALL: Mọi tính năng dọn RAM đều bắt buộc đã mở khóa PRO
        if path in ("/api/trim", "/api/kill", "/api/boost"):
            lic = read_license()
            if not lic["unlocked"]:
                self._send_json({
                    "ok": False,
                    "locked": True,
                    "device_id": lic["device_id"],
                    "checkout_url": build_checkout_url(ACTIVE_PORT),
                    "message": "Tính năng dọn RAM yêu cầu mở khóa SILENT PRO qua MoMo.",
                }, 402)
                return

        if path == "/api/trim":
            ok_c, total_c = core.trim_group(data.get("pids", []))
            self._send_json({"ok": ok_c > 0, "message": f"Đã nén RAM mềm {ok_c}/{total_c} tiến trình {data.get('name', '')}."})
            return

        if path == "/api/kill":
            res = core.terminate_group(data.get("name", ""), data.get("pids", []), data.get("exe", ""))
            self._send_json(res)
            return

        if path == "/api/boost":
            res = core.run_smart_boost(bool(data.get("close_green", False)))
            self._send_json(res)
            return

        self._send_json({"error": "Not found"}, 404)


def launch_edge_app_window(url: str) -> bool:
    edge_paths = [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    ]
    for ep in edge_paths:
        if os.path.exists(ep):
            subprocess.Popen([ep, f"--app={url}", "--window-size=1240,760"])
            return True
    return False


def main():
    global ACTIVE_PORT
    ACTIVE_PORT = find_free_port()
    server = ThreadingHTTPServer(("127.0.0.1", ACTIVE_PORT), SilentAPIHandler)
    url = f"http://127.0.0.1:{ACTIVE_PORT}/index.html"

    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    print(f"[SILENT_WEB_A] Đang chạy tại {url} | Device ID: {get_device_id()}")

    if "--headless" in sys.argv:
        try:
            t.join()
        except KeyboardInterrupt:
            server.shutdown()
        return

    try:
        import webview
        webview.create_window("SILENT RAM & Process Studio — Edition A", url, width=1240, height=760, min_size=(960, 620))
        webview.start()
    except ImportError:
        if not launch_edge_app_window(url):
            webbrowser.open(url)
        try:
            t.join()
        except KeyboardInterrupt:
            pass
    finally:
        server.shutdown()


if __name__ == "__main__":
    main()
