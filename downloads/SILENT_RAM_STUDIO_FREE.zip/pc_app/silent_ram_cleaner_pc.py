import ctypes
import gc
import json
import os
import tkinter as tk
from tkinter import messagebox, ttk

try:
    import psutil
except ImportError:
    psutil = None

DB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "process_advisor_db.json")


def load_advisor_db():
    if os.path.exists(DB_FILE):
        with open(DB_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"red_do_not_close": {}, "yellow_caution": {}, "green_safe_to_close": {}}


def trim_process_working_set(pid: int) -> bool:
    """Nén bộ nhớ làm việc (Working Set) của tiến trình qua Windows API mà không tắt app."""
    PROCESS_SET_QUOTA = 0x0100
    PROCESS_QUERY_INFORMATION = 0x0400
    try:
        handle = ctypes.windll.kernel32.OpenProcess(PROCESS_SET_QUOTA | PROCESS_QUERY_INFORMATION, False, int(pid))
        if not handle:
            return False
        try:
            res = ctypes.windll.psapi.EmptyWorkingSet(handle)
            return bool(res)
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
    except Exception:
        return False


class SilentRamStudioApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("SILENT // RAM & Process Studio PRO")
        self.root.geometry("1080x680")
        self.root.minsize(900, 560)

        self.db = load_advisor_db()
        self.filter_tier = "ALL"
        self.rows_data = []
        self.ram_history = []

        self._apply_theme()
        self._build_layout()
        self.refresh_data()

    def _apply_theme(self):
        self.bg_main = "#0B0F17"
        self.bg_panel = "#131A26"
        self.bg_card = "#192232"
        self.border_col = "#263248"
        self.fg_text = "#F3F4F6"
        self.fg_muted = "#9CA3AF"
        self.accent_blue = "#3B82F6"
        self.accent_green = "#10B981"
        self.accent_amber = "#F59E0B"
        self.accent_red = "#EF4444"

        self.root.configure(bg=self.bg_main)
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure(
            "Pro.Treeview",
            background=self.bg_card,
            foreground=self.fg_text,
            fieldbackground=self.bg_card,
            bordercolor=self.border_col,
            rowheight=32,
            font=("Segoe UI", 10)
        )
        style.configure(
            "Pro.Treeview.Heading",
            background="#0F172A",
            foreground="#E2E8F0",
            font=("Segoe UI", 9, "bold"),
            relief="flat"
        )
        style.map(
            "Pro.Treeview",
            background=[("selected", "#2563EB")],
            foreground=[("selected", "#FFFFFF")]
        )

    def classify_process(self, pname: str):
        key = pname.lower().strip()
        red = self.db.get("red_do_not_close", {})
        yellow = self.db.get("yellow_caution", {})
        green = self.db.get("green_safe_to_close", {})

        if key in red:
            info = red[key]
            return "RED", "KHÔNG NÊN ĐÓNG", info["title"], info["role"], info["consequence"], info["advice"]
        if key in yellow:
            info = yellow[key]
            return "YELLOW", "CÂN NHẮC", info["title"], info["role"], info["consequence"], info["advice"]
        if key in green:
            info = green[key]
            return "GREEN", "AN TOÀN ĐỂ ĐÓNG", info["title"], info["role"], info["consequence"], info["advice"]

        # Quy tắc dự phòng thông minh cho tiến trình chưa có trong danh mục
        if any(k in key for k in ("updater", "update", "crashpad", "helper", "overlay")):
            return (
                "GREEN",
                "AN TOÀN ĐỂ ĐÓNG",
                "Tác vụ phụ / Trình cập nhật",
                "Tiến trình phụ trợ hoặc kiểm tra cập nhật nền.",
                "Tạm dừng cập nhật hoặc tính năng phụ cho đến lần mở tiếp theo.",
                "Có thể đóng nếu đang cần giải phóng bộ nhớ nhanh."
            )
        return (
            "YELLOW",
            "CÂN NHẮC",
            pname,
            "Tiến trình ứng dụng/dịch vụ đang hoạt động trên máy.",
            "Có thể làm mất trạng thái công việc hoặc kết nối của ứng dụng đó.",
            "Kiểm tra ứng dụng tương ứng hoặc thử Nén RAM mềm trước khi đóng hẳn."
        )

    def _build_layout(self):
        # Top bar
        top = tk.Frame(self.root, bg="#080B11", height=58)
        top.pack(fill=tk.X)
        top.pack_propagate(False)

        tk.Label(
            top, text="SILENT", bg="#2563EB", fg="#FFFFFF",
            font=("Segoe UI", 11, "bold"), padx=10, pady=4
        ).pack(side=tk.LEFT, padx=(16, 10), pady=13)

        tk.Label(
            top, text="RAM & Process Studio — Smart Advisor",
            bg="#080B11", fg=self.fg_text, font=("Segoe UI", 13, "bold")
        ).pack(side=tk.LEFT, pady=13)

        self.lbl_ram_badge = tk.Label(
            top, text="RAM: --%", bg="#1E293B", fg="#F8FAFC",
            font=("Segoe UI", 10, "bold"), padx=12, pady=5
        )
        self.lbl_ram_badge.pack(side=tk.RIGHT, padx=16, pady=12)

        # Body split: Left (Monitor + Table) | Right (Process Advisor)
        body = tk.Frame(self.root, bg=self.bg_main)
        body.pack(fill=tk.BOTH, expand=True, padx=14, pady=12)

        left = tk.Frame(body, bg=self.bg_main)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))

        right = tk.Frame(body, bg=self.bg_panel, width=330, highlightbackground=self.border_col, highlightthickness=1)
        right.pack(side=tk.RIGHT, fill=tk.Y)
        right.pack_propagate(False)

        # KPI + Sparkline card
        top_card = tk.Frame(left, bg=self.bg_panel, highlightbackground=self.border_col, highlightthickness=1)
        top_card.pack(fill=tk.X, pady=(0, 10))

        kpi_line = tk.Frame(top_card, bg=self.bg_panel)
        kpi_line.pack(fill=tk.X, padx=14, pady=(10, 6))

        self.lbl_used = tk.Label(kpi_line, text="Đang dùng: -- GB", bg=self.bg_panel, fg=self.fg_text, font=("Segoe UI", 12, "bold"))
        self.lbl_used.pack(side=tk.LEFT, padx=(0, 20))

        self.lbl_avail = tk.Label(kpi_line, text="Khả dụng: -- GB", bg=self.bg_panel, fg=self.accent_green, font=("Segoe UI", 12, "bold"))
        self.lbl_avail.pack(side=tk.LEFT, padx=(0, 20))

        self.lbl_saved = tk.Label(kpi_line, text="Đã dọn phiên này: 0.0 MB", bg=self.bg_panel, fg=self.accent_blue, font=("Segoe UI", 11, "bold"))
        self.lbl_saved.pack(side=tk.RIGHT)

        self.spark_canvas = tk.Canvas(top_card, height=58, bg=self.bg_card, highlightthickness=0)
        self.spark_canvas.pack(fill=tk.X, padx=14, pady=(0, 10))

        # Filter + Action bar
        act_bar = tk.Frame(left, bg=self.bg_main)
        act_bar.pack(fill=tk.X, pady=(0, 8))

        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *_: self._render_table())
        ent = tk.Entry(act_bar, textvariable=self.search_var, bg=self.bg_card, fg=self.fg_text, insertbackground=self.fg_text, relief=tk.FLAT, font=("Segoe UI", 10), width=18)
        ent.pack(side=tk.LEFT, ipady=5, padx=(0, 8))

        for code, label in [("ALL", "Tất cả"), ("GREEN", "Xanh (An toàn)"), ("YELLOW", "Vàng"), ("RED", "Đỏ")]:
            tk.Button(
                act_bar, text=label, bg="#1E293B", fg=self.fg_text, relief=tk.FLAT,
                font=("Segoe UI", 9, "bold"), padx=8, pady=5, cursor="hand2",
                command=lambda c=code: self._set_filter(c)
            ).pack(side=tk.LEFT, padx=(0, 5))

        tk.Button(
            act_bar, text="Smart Boost", bg=self.accent_green, fg="#06281E", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), padx=10, pady=5, cursor="hand2",
            command=self.smart_boost
        ).pack(side=tk.RIGHT, padx=(6, 0))

        tk.Button(
            act_bar, text="Làm mới", bg=self.accent_blue, fg="#FFFFFF", relief=tk.FLAT,
            font=("Segoe UI", 9, "bold"), padx=10, pady=5, cursor="hand2",
            command=self.refresh_data
        ).pack(side=tk.RIGHT)

        # Table
        tbl_wrap = tk.Frame(left, bg=self.bg_panel, highlightbackground=self.border_col, highlightthickness=1)
        tbl_wrap.pack(fill=tk.BOTH, expand=True)

        cols = ("pid", "name", "tier_lbl", "ram_mb")
        self.tree = ttk.Treeview(tbl_wrap, columns=cols, show="headings", style="Pro.Treeview")
        self.tree.heading("pid", text="PID")
        self.tree.heading("name", text="TIẾN TRÌNH")
        self.tree.heading("tier_lbl", text="MỨC ĐỘ")
        self.tree.heading("ram_mb", text="RAM")

        self.tree.column("pid", width=70, anchor="center")
        self.tree.column("name", width=270, anchor="w")
        self.tree.column("tier_lbl", width=155, anchor="center")
        self.tree.column("ram_mb", width=105, anchor="e")

        self.tree.bind("<<TreeviewSelect>>", self._on_select_row)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        sb = ttk.Scrollbar(tbl_wrap, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)

        # Right panel: Tư vấn Tiến trình
        tk.Label(right, text="TƯ VẤN TIẾN TRÌNH (ADVISOR)", bg=self.bg_panel, fg=self.fg_text, font=("Segoe UI", 11, "bold")).pack(
            anchor="w", padx=14, pady=(14, 8)
        )

        self.lbl_adv_badge = tk.Label(right, text="CHỌN 1 TIẾN TRÌNH", bg="#334155", fg="#FFFFFF", font=("Segoe UI", 9, "bold"), padx=10, pady=4)
        self.lbl_adv_badge.pack(anchor="w", padx=14)

        self.lbl_adv_title = tk.Label(right, text="--", bg=self.bg_panel, fg=self.fg_text, font=("Segoe UI", 12, "bold"), wraplength=295, justify="left")
        self.lbl_adv_title.pack(anchor="w", padx=14, pady=(8, 6))

        self.lbl_adv_role = tk.Label(right, text="Vai trò: --", bg=self.bg_panel, fg=self.fg_muted, font=("Segoe UI", 9), wraplength=295, justify="left")
        self.lbl_adv_role.pack(anchor="w", padx=14, pady=(0, 8))

        self.lbl_adv_cons = tk.Label(right, text="Nếu đóng: --", bg=self.bg_panel, fg="#FCA5A5", font=("Segoe UI", 9), wraplength=295, justify="left")
        self.lbl_adv_cons.pack(anchor="w", padx=14, pady=(0, 8))

        self.lbl_adv_advice = tk.Label(right, text="Khuyến nghị: --", bg=self.bg_panel, fg="#6EE7B7", font=("Segoe UI", 9, "bold"), wraplength=295, justify="left")
        self.lbl_adv_advice.pack(anchor="w", padx=14, pady=(0, 14))

        self.btn_trim = tk.Button(
            right, text="Nén RAM mềm (Trim Working Set)", bg="#1D4ED8", fg="#FFFFFF",
            relief=tk.FLAT, font=("Segoe UI", 9, "bold"), pady=8, cursor="hand2",
            command=self.trim_selected
        )
        self.btn_trim.pack(fill=tk.X, padx=14, pady=(0, 8))

        self.btn_kill = tk.Button(
            right, text="Đóng tiến trình đã chọn", bg=self.accent_red, fg="#FFFFFF",
            relief=tk.FLAT, font=("Segoe UI", 9, "bold"), pady=8, cursor="hand2",
            command=self.kill_selected
        )
        self.btn_kill.pack(fill=tk.X, padx=14)

    def _set_filter(self, code):
        self.filter_tier = code
        self._render_table()

    def _draw_sparkline(self):
        self.spark_canvas.delete("all")
        w = max(self.spark_canvas.winfo_width(), 200)
        h = 58
        if len(self.ram_history) < 2:
            return
        step = w / max(1, len(self.ram_history) - 1)
        pts = []
        for i, val in enumerate(self.ram_history):
            x = i * step
            y = h - (max(0.0, min(100.0, val)) / 100.0) * (h - 10) - 5
            pts.extend([x, y])
        self.spark_canvas.create_line(pts, fill=self.accent_blue, width=2.5, smooth=True)

    def refresh_data(self):
        if psutil is None:
            return
        vm = psutil.virtual_memory()
        used_gb = vm.used / (1024 ** 3)
        avail_gb = vm.available / (1024 ** 3)
        total_gb = vm.total / (1024 ** 3)

        self.lbl_used.config(text=f"Đang dùng: {used_gb:.2f}/{total_gb:.2f} GB ({vm.percent:.0f}%)")
        self.lbl_avail.config(text=f"Khả dụng: {avail_gb:.2f} GB")

        badge_bg = self.accent_green if vm.percent < 70 else (self.accent_amber if vm.percent < 85 else self.accent_red)
        self.lbl_ram_badge.config(text=f"RAM: {vm.percent:.0f}%", bg=badge_bg)

        self.ram_history.append(vm.percent)
        self.ram_history = self.ram_history[-40:]
        self.root.after(40, self._draw_sparkline)

        collected = []
        for p in psutil.process_iter(["pid", "name", "memory_info"]):
            try:
                info = p.info
                pname = (info.get("name") or "").strip()
                if not pname:
                    continue
                mem = info.get("memory_info")
                ram_mb = (mem.rss / (1024 ** 2)) if mem else 0.0
                if ram_mb < 15.0:
                    continue
                tier, tier_lbl, title, role, cons, advice = self.classify_process(pname)
                collected.append({
                    "pid": info["pid"],
                    "name": pname,
                    "tier": tier,
                    "tier_lbl": tier_lbl,
                    "ram_mb": ram_mb,
                    "title": title,
                    "role": role,
                    "cons": cons,
                    "advice": advice
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        collected.sort(key=lambda x: x["ram_mb"], reverse=True)
        self.rows_data = collected[:90]
        self._render_table()

    def _render_table(self):
        for iid in self.tree.get_children():
            self.tree.delete(iid)
        kw = self.search_var.get().strip().lower()
        for r in self.rows_data:
            if self.filter_tier != "ALL" and r["tier"] != self.filter_tier:
                continue
            if kw and kw not in r["name"].lower() and kw not in r["title"].lower():
                continue
            self.tree.insert("", tk.END, iid=str(r["pid"]), values=(r["pid"], r["name"], r["tier_lbl"], f"{r['ram_mb']:.1f} MB"))

    def _get_selected_record(self):
        sel = self.tree.selection()
        if not sel:
            return None
        pid_str = sel[0]
        for r in self.rows_data:
            if str(r["pid"]) == pid_str:
                return r
        return None

    def _on_select_row(self, _event=None):
        rec = self._get_selected_record()
        if not rec:
            return
        tier = rec["tier"]
        badge_col = self.accent_red if tier == "RED" else (self.accent_amber if tier == "YELLOW" else self.accent_green)
        self.lbl_adv_badge.config(text=f"{rec['tier_lbl']} ({rec['name']})", bg=badge_col, fg="#FFFFFF")
        self.lbl_adv_title.config(text=rec["title"])
        self.lbl_adv_role.config(text=f"Vai trò: {rec['role']}")
        self.lbl_adv_cons.config(text=f"Nếu đóng: {rec['cons']}")
        self.lbl_adv_advice.config(text=f"SILENT khuyên: {rec['advice']}")

        if tier == "RED":
            self.btn_kill.config(state=tk.DISABLED, bg="#4B5563", text="Đã khóa (Lõi hệ thống)")
        else:
            self.btn_kill.config(state=tk.NORMAL, bg=self.accent_red, text="Đóng tiến trình đã chọn")

    def trim_selected(self):
        rec = self._get_selected_record()
        if not rec:
            messagebox.showwarning("SILENT Advisor", "Hãy chọn một tiến trình trước.")
            return
        ok = trim_process_working_set(rec["pid"])
        messagebox.showinfo("SILENT Smart Trim", f"Đã gửi yêu cầu nén bộ nhớ cho {rec['name']} (PID {rec['pid']}): {'Thành công' if ok else 'Bị giới hạn quyền'}.")
        self.refresh_data()

    def kill_selected(self):
        rec = self._get_selected_record()
        if not rec:
            return
        if rec["tier"] == "RED":
            messagebox.showerror("Cảnh báo SILENT", "Tiến trình thuộc nhóm KHÔNG NÊN ĐÓNG.")
            return
        if rec["tier"] == "YELLOW":
            ans = messagebox.askyesno("Cảnh báo tiến trình vàng", f"{rec['name']} thuộc nhóm CÂN NHẮC.
{rec['cons']}
Bạn vẫn muốn đóng?")
            if not ans:
                return
        try:
            psutil.Process(int(rec["pid"])).terminate()
            messagebox.showinfo("SILENT", f"Đã dừng tiến trình {rec['name']}.")
        except Exception as e:
            messagebox.showerror("Lỗi", f"Không thể dừng tiến trình: {e}")
        self.refresh_data()

    def smart_boost(self):
        before = psutil.virtual_memory().available / (1024 ** 2) if psutil else 0.0
        gc.collect()
        trimmed = 0
        for r in self.rows_data:
            if r["tier"] == "YELLOW" and r["ram_mb"] > 80.0:
                if trim_process_working_set(r["pid"]):
                    trimmed += 1
        temp_dir = os.environ.get("TEMP", "")
        freed_tmp = 0
        if temp_dir and os.path.isdir(temp_dir):
            for root_d, _, files in os.walk(temp_dir):
                for fn in files:
                    if fn.endswith((".tmp", ".log", ".bak")):
                        fp = os.path.join(root_d, fn)
                        try:
                            sz = os.path.getsize(fp)
                            os.remove(fp)
                            freed_tmp += sz
                        except OSError:
                            pass
        self.refresh_data()
        after = psutil.virtual_memory().available / (1024 ** 2) if psutil else 0.0
        gain = max(0.0, after - before)
        self.lbl_saved.config(text=f"Đã dọn phiên này: +{gain:.1f} MB")
        messagebox.showinfo(
            "SILENT Smart Boost",
            f"Đã tối ưu {trimmed} tiến trình nền, dọn {freed_tmp / (1024**2):.1f} MB file tạm.
RAM khả dụng thay đổi: +{gain:.1f} MB."
        )


if __name__ == "__main__":
    root = tk.Tk()
    SilentRamStudioApp(root)
    root.mainloop()
